﻿var SendMail = function () {
    var mailRequest = {
        "Name": $("#name").val(),
        "From": $("#email").val(),
        "Subject": $("#subject").val(),
        "Content": $("#content").val()
    };
    $.ajax({
        type: 'POST',
        url: '/Contact/SendMail',
        contentType: 'application/json',
        dataType: 'JSON',
        data: JSON.stringify(mailRequest),
        success: function (result) {
            debugger;
            if (result.status !== 200) {
                alert(result.errorMessage);
                return;
            }
            alert('Successfully received Data ');
            console.log(result);
        },
        error: function () {
            alert('Failed to receive the Data');
            console.log('Failed ');
        }
    });
}