﻿namespace SkillSparkEdu.MVC.Models
{
    public class SendMailRequest
    {
        public string Subject { get; set; }
        public string Content { get; set; }
        public string From { get; set; }
        public string Name { get; set; }
    }
}
