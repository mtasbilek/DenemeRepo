﻿using Microsoft.AspNetCore.Mvc;

namespace SkillSparkEdu.MVC.Controllers
{
    public class PageUnderConstructionController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}