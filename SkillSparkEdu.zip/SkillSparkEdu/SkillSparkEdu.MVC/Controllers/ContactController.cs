﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Mail;
using System.Net;
using System.Text.Encodings.Web;
using SkillSparkEdu.MVC.Models;

namespace SkillSparkEdu.MVC.Controllers
{
    public class ContactController : Controller
    {

        [HttpPost]
        public async Task<IActionResult> SendMail([FromBody] SendMailRequest sendMailRequest)
        {
            try
            {
                string encodedContent = HtmlEncoder.Default.Encode(sendMailRequest.Content.Trim());
                MailMessage msg = new MailMessage();
                SmtpClient smtpClient = new SmtpClient();
                msg.From = new MailAddress(sendMailRequest.From.Trim());
                msg.To.Add("info@skillsparkedu.com");
                msg.Subject = sendMailRequest.Subject.Trim();
                msg.IsBodyHtml = true;
                msg.Body = "<p>Name: " + sendMailRequest.Name.Trim() + "</p><p>Email: " + sendMailRequest.From.Trim() + "</p><br><br><p>" + encodedContent + "</p>";

                smtpClient.Port = 587;
                smtpClient.Host = "smtp.gmail.com";
                smtpClient.EnableSsl = true;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = new NetworkCredential("skillsparkeducontact@gmail.com", "sebc znmu qebn gngj");
                smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;

                smtpClient.Send(msg);
                return Json(new { Status = HttpStatusCode.OK });
            }
            catch (Exception ex)
            {
                return Json(new { Status = HttpStatusCode.InternalServerError, ErrorMessage = ex.Message });
            }
        }
    }
}