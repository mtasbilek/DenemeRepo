﻿$(".nav-link").click(function () {
    if (window.location.pathname !== "/") {
        localStorage.setItem("sectionName", $(this).attr("href"))
        window.location.href = window.location.origin;
    }
});

$(document).ready(function () {
    let sectionName = localStorage.getItem("sectionName");
    if (sectionName && sectionName !== "") {
        $(".nav-link[href='" + sectionName + "']").click();
        localStorage.removeItem("sectionName");
    }
})