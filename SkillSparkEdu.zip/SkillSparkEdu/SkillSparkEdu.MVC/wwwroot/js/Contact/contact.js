﻿var SendMail = function () {
    var mailRequest = {
        "Name": $("#name").val(),
        "From": $("#email").val(),
        "Subject": $("#subject").val(),
        "Content": $("#content").val()
    };
    $.ajax({
        type: 'POST',
        url: '/Contact/SendMail',
        contentType: 'application/json',
        dataType: 'JSON',
        data: JSON.stringify(mailRequest),
        success: function (result) {
            if (result.status !== 200) {
                alert(result.errorMessage);
                return;
            }
            $("#name").val("");
            $("#email").val("");
            $("#subject").val("");
            $("#content").val("");
            alert('Mail successfully sent');

        },
        error: function () {
            alert('Failed to sending mail');
        }
    });
}